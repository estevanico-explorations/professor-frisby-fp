## Professor Frisby Introduces Composable Functional JavaScript

[![Book cover](cover.png)](https://egghead.io/courses/professor-frisby-introduces-composable-functional-javascript)

Personal code while watching [Composable Functional JavaScript](https://egghead.io/courses/professor-frisby-introduces-composable-functional-javascript). Fun course.

---
[Sean Omlor](http://seanomlor.com)
