[![Travis](https://img.shields.io/travis/jongold/frisby.svg)](https://travis-ci.org/jongold/frisby)This code might be broken on incomplete; do the course instead!

My scratchpad from Dr Boolean's excellent [Professor Frisby Introduces Composable Functional JavaScript](https://egghead.io/courses/professor-frisby-introduces-composable-functional-javascript) course.
